import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Addition extends HttpServlet
{


public  void service(HttpServletRequest req,HttpServletResponse res) throws IOException
{

PrintWriter out=res.getWriter();
int first=Integer.parseInt(req.getParameter("t1"));
int second=Integer.parseInt(req.getParameter("t2"));
int c=first+second;
out.print("sum is "+c);

}

}
