import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterController extends HttpServlet
{
   public void service(HttpServletRequest req,HttpServletResponse res) throws IOException   
   {
  PrintWriter out=res.getWriter();
  String name=req.getParameter("t1");
  String email=req.getParameter("t2");
  String pwd=req.getParameter("t3");
  long mobile=Long.parseLong(req.getParameter("t4"));
  String adr=req.getParameter("t5");
  int i=0;
  try {
  Class.forName("org.h2.Driver");
  Connection con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/apachetomcat","pavan","pavan");
  PreparedStatement pstmt=con.prepareStatement("insert into tomcat values(?,?,?,?,?)");
  pstmt.setString(1,name);
  pstmt.setString(2,email);
  pstmt.setString(3,pwd);
  pstmt.setLong(4, mobile);;
  pstmt.setString(5,adr);
i= pstmt.executeUpdate();
if(i>0)
  {
  out.print("Registration completed Successfully");
  }
  else
  {
  out.print("error in registration");
  }
  }
  catch(Exception e)
  {
  System.out.println(e);
  }
   out.close();
   
   }
}