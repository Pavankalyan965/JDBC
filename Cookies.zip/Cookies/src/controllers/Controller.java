package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/reqlogin")
public class Controller extends HttpServlet 
{
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		String name=req.getParameter("t1");
		String pwd=req.getParameter("t2");
		PrintWriter out=res.getWriter();
		
		if(name.equals("pavan") && pwd.equals("pavan"))
		{
			Cookie ck=new Cookie("name", name);
			res.addCookie(ck);
			RequestDispatcher rd=req.getRequestDispatcher("reqwelcome");
			rd.forward(req, res);
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("reqlogin");
			rd.include(req, res);
			out.print("invalid credentials");
		}
	}
}
