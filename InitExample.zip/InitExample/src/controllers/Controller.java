package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.UserModel;
import dao.Dao;

@WebServlet(urlPatterns = {"/reqregform","/reqloginform","/reqreg","/reqlogin"})
public class Controller extends HttpServlet 
{
	Dao obj;
	public void init() throws ServletException
	{
		super.init();
		obj=new Dao();
	}
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		String path=req.getServletPath();
		PrintWriter out=res.getWriter();
		 if(path.equals("/reqreg"))
		{
			UserModel u=new UserModel();
			u.setName(req.getParameter("t1"));
			u.setPassword(req.getParameter("t2"));
			u.setEmail(req.getParameter("t3"));
			u.setMobile(Long.parseLong(req.getParameter("t4").trim()));
			u.setCity(req.getParameter("t5"));
			boolean b=obj.register(u);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("reg.html");
				rd.forward(req, res);
				out.print("Registration done successfully click here to <a href=login.html>");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("reg.html");
				rd.include(req, res);
				out.print("Registration failed");
			}
		}
		else if(path.equals("/reqlogin"))
		{
			UserModel u=new UserModel();
			u.setName(req.getParameter("t1"));
			u.setPassword(req.getParameter("t2"));
			boolean b= obj.login(u);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
				rd.forward(req, res);
				out.print("Logged in successfully");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.include(req, res);
				out.print("Login failed");
			}
		}
	}
}
