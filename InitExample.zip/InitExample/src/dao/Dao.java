
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import Model.UserModel;

public class Dao 
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try
		{
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/dao","dao","dao");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	public boolean register(UserModel u)
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		try
		{
			PreparedStatement ps=con.prepareStatement("insert into users values(?,?,?,?,?)");
			ps.setString(1, u.getName());
			ps.setString(2, u.getPassword());
			ps.setString(3, u.getEmail());
			ps.setLong(4, u.getMobile());
			ps.setString(5, u.getCity());
			int i=ps.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
		
	}
	public boolean login(UserModel u)
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select name,password from users where name='"+u.getName()+"' and password='"+u.getPassword()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
}
