import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterController extends HttpServlet 
{
	public void service(HttpServletRequest req,HttpServletResponse reg) throws IOException
	{
		PrintWriter out=reg.getWriter();
		String name=req.getParameter("t1");
		long mobile=Long.parseLong(req.getParameter("t2"));
		String email=req.getParameter("t3");
		String adr=req.getParameter("t4");
		out.println("Name:"+name);
		out.println("Mobile:"+mobile);
		out.println("Email:"+email);
		out.println("Address:"+adr);
		
	}
}
