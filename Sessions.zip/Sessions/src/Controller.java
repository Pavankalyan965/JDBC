import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import model.User;
@WebServlet("/reqlogin")
public class Controller extends HttpServlet 
{
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
		User u =new User();
		String email=null;
		u.setName(req.getParameter("t1"));
		u.setPwd(req.getParameter("t2"));
		boolean b=new Dao().login(u);
		if(b)
		{
			email=new Dao().getEmailbyName(u.getName());
			Cookie ck=new Cookie("email",email);
			res.addCookie(ck);
			RequestDispatcher rd=req.getRequestDispatcher("reqwelcome");
			rd.forward(req, res);
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("index.html");
			rd.include(req, res);
			out.print("Invalid username/password");
		}
	}
}
