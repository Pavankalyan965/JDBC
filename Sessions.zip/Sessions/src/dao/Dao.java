package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import model.User;

public class Dao 
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try
		{
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/dao","dao","dao");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
		
	}
	public boolean login(User u)
	{
		boolean b=false;
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select name,pwd from student where name='"+u.getName()+"' and pwd='"+u.getPwd()+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;		
	}
	public String getEmailbyName(String name)
	{
		String email=null;
		ResultSet rs=null;
		try
		{
			Statement st=con.createStatement();
			rs=st.executeQuery("select email from student where name='"+name+"'");
			if(rs.next())
			{
				email=rs.getString(1);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return email;
		
	}
}
