import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Controller extends HttpServlet
{
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
		String path=req.getServletPath();
		if(path.equals("/reqlogin"))
		{
			String name=req.getParameter("t1");
			String password=req.getParameter("t2");
			boolean b=new Dao().login(name,password);
			if(b)
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
    			rd.include(req, res);
    		}
    		else
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("index.html");
    			rd.include(req, res);
    			out.print("invalid user");
    		}
		}
		else if(path.equals("/reqreg"))
		{
			String name=req.getParameter("t1");
			String pwd=req.getParameter("t2");		
			String email=req.getParameter("t3");		
			String city=req.getParameter("t4");
			boolean b=new Dao().register(name,pwd,email, city);
			if(b)
			{
				out.print("Registration done successfully");
			}
			else
			{
				out.print("registration failed");
			}
		}
		else if(path.equals("/reqallusers"))
		{
			String name=req.getParameter("t1");
			String pwd=req.getParameter("t2");		
			String email=req.getParameter("t3");		
			String city=req.getParameter("t4");
			ResultSet rs=new Dao().viewAll();
			out.print("<table border=3 cellpadding=7><tr bgcolor=yellow><td>name</td><td>Password</td><td>Email ID</td><td>city</td><td>updateuser</td><td>deleteuser</td></tr>");
			try {
				while(rs.next())
				{
					out.print("<body><tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td><a href=requpdate?id="+rs.getString(1)+">Update</a></td><td><a href=reqdelete?del="+rs.getString(1)+">delete</a></td></tr>");
				}
			}
			catch (SQLException e) 
			{
				System.out.println(e);
			}
		}
		else if(path.equals("/requpdate"))
    	{
    		ResultSet rs=null;
    		String name=req.getParameter("id");
    		rs=new Dao().update(name);
    		try
    		{
    			while(rs.next())
    			{
    				out.print("<body><form action=detailsupdate>Name: <input type=text name=t1 readonly value="+rs.getString(1)+"><br>");
    				out.print("Password: <input type=text name=t2 value="+rs.getString(2)+"><br>");
    				out.print("Email: <input type=text name=t3 value="+rs.getString(3)+"><br>");
    				out.print("City: <input type=text name=t4 value="+rs.getString(4)+"><br>");
    				out.print("<input type=submit value=update><input type=Reset value=clear></form>");
    			}
    		}
    		catch(Exception e)
    		{
    			System.out.println(e);
    		}
    	}
    	else if(path.equals("/detailsupdate"))
    	{
    		ResultSet rs=null;
    		String name=req.getParameter("t1");
    		String pwd=req.getParameter("t2");
    		String email=req.getParameter("t3");
    		String city=req.getParameter("t4");
    		
    		boolean b=new Dao().updateDetails(name,pwd, email, city);
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("/reqallusers");
				rd.forward(req, res);
			}
			else
			{
				out.print("failed");
			}
    	}
    	else if(path.equals("/reqdelete"))
    	{
    		String name=req.getParameter("del");
    		boolean b=new Dao().delete(name);
    		if(b)
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
				rd.forward(req, res);
    		}
    		else
    		{
    			out.print("failed");
    		}
    	}
    }



}
