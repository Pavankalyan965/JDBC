import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Dao
{
	static Connection con=null;
	public static Connection getConnectionObject()
	{
		try
		{
			Class.forName("org.h2.Driver");
			con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/dao","dao","dao");
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}
	public boolean login(String name,String pwd)
	{
		boolean b=false;
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select name,pwd from model where name='"+name+"' and pwd='"+pwd+"'");
			if(rs.next())
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean register(String name,String password,String email,String city)
	{
		boolean b=false;
		int i=0;
		con=Dao.getConnectionObject();
		try {
			PreparedStatement pstmt=con.prepareStatement("insert into model values(?,?,?,?)");
			pstmt.setString(1, name);
			pstmt.setString(2, password);
			pstmt.setString(3, email);
			pstmt.setString(4, city);
			i=pstmt.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public ResultSet viewAll()
	{
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select * from model");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public ResultSet update(String name)
	{
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			rs=stmt.executeQuery("select * from model where name='"+name+"'");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return rs;
	}
	public boolean updateDetails(String name,String pwd,String email,String city)
	{
		boolean b=false;
		ResultSet rs=null;
		con=Dao.getConnectionObject();
		int i=0;
		try
		{
			Statement stmt=con.createStatement();
			i=stmt.executeUpdate("update model set pwd='"+pwd+"',email='"+email+"',city='"+city+"' where name='"+name+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}
	public boolean delete(String name)
	{
		boolean b=false;
		con=Dao.getConnectionObject();
		int i=0;
		try
		{
			Statement stmt=con.createStatement();
			i=stmt.executeUpdate("delete from model where name='"+name+"'");
			if(i>0)
			{
				b=true;
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
	}

}
