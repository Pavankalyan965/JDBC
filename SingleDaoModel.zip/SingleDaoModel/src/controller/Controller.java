package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import model.RegisterModel;

public class Controller extends HttpServlet 
{
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		PrintWriter out=res.getWriter();
		String path=req.getServletPath();
		RegisterModel rm=new RegisterModel();
		if(path.equals("/reqlogin"))
		{
			rm.setName(req.getParameter("t1"));
			rm.setPwd(req.getParameter("t2"));
			boolean b=new Dao().login(rm.getName(),rm.getPwd());
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
				rd.include(req, res);
				out.print("Login completed successfully");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("login.html");
				rd.include(req, res);
				out.print("Login failed");
			}
		}
		else if(path.equals("/reqreg"))
		{
			rm.setName(req.getParameter("t1"));
			rm.setPwd(req.getParameter("t2"));
			rm.setEmail(req.getParameter("t3"));
			rm.setCity(req.getParameter("t4"));
			boolean b=new Dao().register(rm.getName(), rm.getPwd(), rm.getEmail(), rm.getCity());
			if(b)
			{
				RequestDispatcher rd=req.getRequestDispatcher("reg.html");
				rd.include(req, res);
				out.print("<body><center><h3>Registration completed successfully. Click here to <a href=login.html>Login</a></h3></center></body>");
			}
			else
			{
				RequestDispatcher rd=req.getRequestDispatcher("reg.html");
				rd.include(req, res);
				out.print("Registration failed");
			}
		}
		else if(path.equals("/reqallusers"))
		{
			ResultSet rs=null;
			rs=new Dao().viewAll();
			out.print("<table border=3 cellpadding=7><tr bgcolor=yellow><td>name</td><td>Password</td><td>Email ID</td><td>city</td><td>updateuser</td><td>deleteuser</td></tr>");
			try {
				while(rs.next())
				{
					out.print("<body><tr><td>"+rs.getString(1)+"</td><td>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"</td><td>"+rs.getString(4)+"</td><td><a href=requpdate?id="+rs.getString(1)+">Update</a></td><td><a href=reqdelete?del="+rs.getString(1)+">delete</a></td></tr>");
				}
			}
			catch (Exception e) 
			{
				System.out.println(e);
			}
		}
		else if(path.equals("/reqdelete"))
    	{
    		rm.setName(req.getParameter("del"));
    		boolean b=new Dao().delete(rm.getName());
    		if(b)
    		{
    			RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
				rd.forward(req, res);
    		}
    		else
    		{
    			out.print("failed");
    		}
    	}
    
		else if(path.equals("/requpdate"))
		{
		ResultSet rs=null;
		rm.setName(req.getParameter("id"));
		rs=new Dao().update(rm.getName());
		try
		{
			while(rs.next())
			{
				out.print("<body><form action=detailsupdate>Name: <input type=text name=t1 readonly value="+rs.getString(1)+"><br>");
				out.print("Password: <input type=text name=t2 value="+rs.getString(2)+"><br>");
				out.print("Email: <input type=text name=t3 value="+rs.getString(3)+"><br>");
				out.print("City: <input type=text name=t4 value="+rs.getString(4)+"><br>");
				out.print("<input type=submit value=update><input type=Reset value=clear></form>");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	else if(path.equals("/detailsupdate"))
	{
		ResultSet rs=null;
		rm.setName(req.getParameter("t1"));
		rm.setPwd(req.getParameter("t2"));
		rm.setEmail(req.getParameter("t3"));
		rm.setCity(req.getParameter("t4"));
		
		boolean b=new Dao().updateDetails(rm.getName(), rm.getPwd(), rm.getEmail(),rm.getCity());
		if(b)
		{
			RequestDispatcher rd=req.getRequestDispatcher("welcome.html");
			rd.forward(req, res);
		}
		else
		{
			out.print("failed");
		}
	}
	}		
}
