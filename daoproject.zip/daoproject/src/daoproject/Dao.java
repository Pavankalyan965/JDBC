package daoproject;

import java.sql.Connection;
import java.sql.DriverManager;

public class Dao
{
	static Connection con=null;
  public static Connection getConnectionObject()
  {
	  try {
		  Class.forName("org.h2.Driver");
		  con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/dao","dao","dao");
	  }
	  catch(Exception e)
	  {
		  System.out.println(e);
	  }
	  
	  return con;
  }
}
