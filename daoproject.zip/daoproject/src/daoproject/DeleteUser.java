package daoproject;

import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.Statement;

	import javax.servlet.RequestDispatcher;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;

	public class DeleteUser extends HttpServlet
	{

		public void service(HttpServletRequest req,HttpServletResponse delete)
		{
			Connection con=null;
			int i=0;
		String name=req.getParameter("id");
		con=Dao.getConnectionObject();
		try 
		{
			
				Statement stmt=con.createStatement();
				i=stmt.executeUpdate("delete from users where name='"+name+"'");
	            if(i>0)
	            {
	            	RequestDispatcher rd=req.getRequestDispatcher("reqallusers");
	            	rd.forward(req, delete);
	            }

		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
	
}
