package daoproject;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginController  extends HttpServlet 
{
	public void service(HttpServletRequest pav,HttpServletResponse kal) throws IOException
	{
	PrintWriter out=kal.getWriter();
	Connection con=null;
	String name=pav.getParameter("t1");
	String password=pav.getParameter("t2");
	ResultSet rs=null;
	try {
		Class.forName("org.h2.Driver");
		con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/dao","dao","dao");
	
		Statement stmt=con.createStatement();
	rs=stmt.executeQuery("select name,password from users where name='"+name+"' and password='"+password+"'");
	if(rs.next())
	{
		RequestDispatcher rd=pav.getRequestDispatcher("Welcome.html");
		rd.forward(pav, kal);
		
	}
	else
	{
		RequestDispatcher rd=pav.getRequestDispatcher("login.html");
		rd.include(pav, kal);
		out.print("<center>Invalid username /password");
		
	}
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
}
	
}
