package daoproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterController extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		Connection con=null;
		int i=0;
		con=Dao.getConnectionObject();
		PrintWriter out=res.getWriter();
		try {
		PreparedStatement pstmt=con.prepareStatement("insert into users values(?,?,?,?,?)");
		pstmt.setString(1, req.getParameter("t1"));
		pstmt.setString(2,req.getParameter("t2"));
		pstmt.setString(3, req.getParameter("t3"));
		pstmt.setLong(4, Long.parseLong(req.getParameter("t4")));
		pstmt.setString(5,req.getParameter("t5"));
		i=pstmt.executeUpdate();
		System.out.println(i);
		if(i>0)
		{
			RequestDispatcher rd=req.getRequestDispatcher("reg.html");
			rd.include(req, res);
			out.print("Registration completed Successfully click here to <a href=login>Login</a>");
		}
		else
		{
			RequestDispatcher rd=req.getRequestDispatcher("reg.html");
			rd.include(req, res);
			out.print("Registration Fail");
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	

}
