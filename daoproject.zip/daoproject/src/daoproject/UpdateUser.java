package daoproject;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateUser extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
		String name=req.getParameter("id");
		Connection con=Dao.getConnectionObject();
		try
		{
			Statement stmt=con.createStatement();
			ResultSet rs=stmt.executeQuery("select * from users where name='"+name+"'");
			if(rs.next())
		      {
		    	  out.print("<body><form action=update>Name : <input type=text name= t1 readonly value="+rs.getString(1)+"><br>");
		    	  out.print("Password : <input type=text name=t2 value="+rs.getString(2)+" ><br>");
		    	  out.print("Email : <input type=text name=t3 value="+rs.getString(3)+"><br>");
		    	  out.print("Mobile : <input type=text name=t4 value="+rs.getLong(4)+" ><br>");
		    	  out.print("City : <input type=text name=t5 value="+rs.getString(5)+"><br>");
		    	  out.print("<input type=submit value=Update><input type=Reset value=clear></form>");
		    }
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}